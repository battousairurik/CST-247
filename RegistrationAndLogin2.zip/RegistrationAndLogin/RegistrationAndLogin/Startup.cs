﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RegistrationAndLogin.Startup))]
namespace RegistrationAndLogin
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
