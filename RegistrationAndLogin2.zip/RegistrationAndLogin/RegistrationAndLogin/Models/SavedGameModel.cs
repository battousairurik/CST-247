﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RegistrationAndLogin.Models
{
    public class SavedGameModel
    {
        public int GameID { get; set; }
        public String JsonGameString { get; set; }

    }
}