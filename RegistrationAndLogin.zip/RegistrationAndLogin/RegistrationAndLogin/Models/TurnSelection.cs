﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RegistrationAndLogin.Models
{
    public class TurnSelection
    {
        public int Column { get; set; }
        public int Row { get; set; }
    }
}