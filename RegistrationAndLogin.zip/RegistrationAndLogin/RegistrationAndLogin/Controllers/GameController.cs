﻿using RegistrationAndLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace RegistrationAndLogin.Controllers
{
    public class GameController : Controller
    {
        // GET: Game
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DifficultySelection()
        {

            return View();
        }

        public GameBoard GameBoard { get; set; }
        public GameLogicController LogicController { get; set; }

        public ActionResult GameDisplayHelper(Difficulty difficulty)
        {
            GameBoard = new GameBoard(difficulty.GameDifficulty * 10);
            LogicController = new GameLogicController(GameBoard);
            GameBoard = LogicController.GameBoard;
            return View(GameBoard);
        }

        public ActionResult GameDisplay(GameBoard _GameBoard)
        {
            GameBoard = _GameBoard;
            
            return View(GameBoard);
        }
    }
}