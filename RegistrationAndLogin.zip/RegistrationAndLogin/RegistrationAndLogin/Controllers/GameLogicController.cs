﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RegistrationAndLogin.Models;

namespace RegistrationAndLogin.Controllers
{
    // To change to be an official controller extend class with ": Controller" and 
    // add namespace "System.Web.Mvc;"
    public class GameLogicController
    {
        GameCellButton[,] gameButtons;
        public GameBoard GameBoard { get; set; }

        public GameLogicController(int boardSize)
        {
            GameBoard = new GameBoard(boardSize);
            GameBoardController gBController = new GameBoardController(GameBoard);
        }

        public GameLogicController (GameBoard _gameBoard)
        {
            GameBoard = _gameBoard;
            GameBoardController gBController = new GameBoardController(GameBoard);
        }


        


    }
}